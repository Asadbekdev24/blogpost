import sys
from PyQt5.QtWidgets import QApplication, QListWidget, QListWidgetItem, QTextEdit, QWidget, QVBoxLayout

class ListWidgetWithTextArea(QListWidget):
    def __init__(self):
        super().__init__()

        # Add a QTextEdit to the QListWidget
        self.addTextAreaItem("This is a sample text.")
        self.addTextAreaItem("This is a sample text.")
        self.addTextAreaItem("This is a sample text.")
        self.addTextAreaItem("This is a sample text.")

    def addTextAreaItem(self, text):
        widget = QWidget()
        
        layout = QVBoxLayout()
        
        text_edit = QTextEdit()
        text_edit.setText(text)
        
        layout.addWidget(text_edit)
        
        widget.setLayout(layout)
        
        item = QListWidgetItem()
        
        item.setSizeHint(widget.sizeHint())
        
        self.addItem(item)
        
        self.setItemWidget(item, widget)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ListWidgetWithTextArea()
    window.show()
    sys.exit(app.exec_())
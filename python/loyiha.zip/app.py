from PyQt5.QtWidgets import QApplication, QMessageBox

from mainpage import MainPage
from loginpage import LoginPage
from registerpage import RegisterPage
from myposts import MyPostsPage
from addpost import AddPostPage
from allposts import AllPostsPage

from database import Database
from os import system


system("clear")


class App:
    USER = None

    def __init__(self) -> None:
        self.boshSahifaOyna = MainPage()
        self.loginOyna = LoginPage()
        self.registerOyna = RegisterPage()
        self.meningPostlarimOyna = MyPostsPage()
        self.postQoshishOyna = AddPostPage()
        self.hammaPostlarOyna = AllPostsPage()

        self.database = Database()

        self.boshSahifaOyna.loginBtn.clicked.connect(self.showLoginPage)
        self.boshSahifaOyna.registerBtn.clicked.connect(self.showRegisterPage)

        self.loginOyna.loginBtn.clicked.connect(self.loginFunction)

        self.boshSahifaOyna.show()


    def loginFunction(self):
        username = self.loginOyna.usernameInput.text()
        password = self.loginOyna.passwordInput.text()

        foundUser = self.database.login(username, password)

        if not foundUser:
            return self.alert("Foydalanuvchi nomi topilmadi!")
    
        self.USER = foundUser
        self.showAllPostsPage()

    
    def alert(self, text: str):
        msgbox = QMessageBox()
        msgbox.setIcon(QMessageBox.Warning)
        msgbox.setText(text)
        msgbox.setStandardButtons(QMessageBox.Ok)

        return msgbox.exec()


    def showLoginPage(self):
        self.loginOyna.show()
        self.boshSahifaOyna.close()


    def showRegisterPage(self):
        self.registerOyna.show()
        self.boshSahifaOyna.close()

    def showAllPostsPage(self):
        self.hammaPostlarOyna.show()
        self.loginOyna.close()
        self.registerOyna.close()



app = QApplication([])

dastur = App()

app.exec()
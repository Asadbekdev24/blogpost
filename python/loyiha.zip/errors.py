class UsernameAlreadyExistsError(Exception):
    pass